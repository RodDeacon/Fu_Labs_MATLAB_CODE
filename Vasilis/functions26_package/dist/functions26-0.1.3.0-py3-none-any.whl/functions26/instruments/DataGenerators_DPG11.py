# 2021-07-06 / last updated on
# This code was made for use in the Fu lab
# by Ethan Hansen


import numpy as np
import pandas as pd

from ..units.frequency import frequency_units_dict
from ..units.UnitClass import UnitClass

import ctypes as C
import sys  # sys.exit(1), sys.stdout.write
import warnings


class DataGeneratorDPG11Instrument:
    CHASE_VERSION = "64bit"

    CHASE_DLL_32_PATH = r'C:\Users\ECE guest\Dropbox\35share\Python\Ethan\DPG11_project\PYTHON_EXAMPLE\dax22000_lib_DLL32.dll'
    CHASE_DLL_64_PATH = r'C:\Users\ECE guest\Dropbox\35share\Python\Ethan\DPG11_project\PYTHON_EXAMPLE\dax22000_lib_DLL64.dll'

    def __init__(self, device_name='', card_number=1, timeout=20000, initialize_at_definition=True):
        self.device_name = device_name
        self.timeout = timeout
        self.initialize_at_definition = initialize_at_definition
        self.cardnumber = card_number
        self.number_of_cards = 1
        self.initialization_output = 0

        # Run the initialization if desired
        if self.initialize_at_definition:
            self.initialize_instrument()

    def initialize_instrument(self):

        # Load the API based on the system architecture and the path of the dll files.
        # Make sure the path and architecture values are correct.
        try:
            if CHASE_VERSION == "32bit":
                chase_dll_path = CHASE_DLL_32_PATH
            elif CHASE_VERSION == "64bit":
                chase_dll_path = CHASE_DLL_64_PATH

            # This accesses the dll library and allows us to send C commands via our python script
            chaseDLL = C.CDLL(chase_dll_path)
        except:
            warnings.warn("Warning could not load Chase AWG dll, check that dll located at '%s'" % chase_dll_path)

        # Check to see the number of DPG11 system detected. This should always be 1 for our current uses
        # If no cards are detected, print a warning and exit the code
        self.number_of_cards = chaseDLL.DAx22000_GetNumCards()
        if self.number_of_cards == 0:
            warnings.warn("No cards found...Exiting system")
            sys.exit(1)

        # Opening the driver on the specific card (defined by self.cardnumber), exiting if we cannot open it
        if chaseDLL.DAx22000_Open(C.c_int32(self.cardnumber)) != 0:
            warnings.warn("Cannot open DAx API...Exiting system")
            sys.exit(1)

        # Initialize the USB controller and the DPG11. If the initialization code outputs 0, then the initialization
        # was a success. If not zero, the the initialization failed
        self.initialization_output = chaseDLL.DAx22000_Initialize(C.c_int32(addr))
        if self.initialziation_output == 0:
            print(self.device_name + ': Instrument successfully initialized')
        else:
            print(self.device_name + ': Instrument failed to initialize')
        return self.initialization_output


