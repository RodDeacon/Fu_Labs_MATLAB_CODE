# 2020-09-14
# This code was made for use in the Fu lab
# by Vasilis Niaouris
# based on ideas and code of Christian Zimmermann
#
# from .DataXXX import DataSIF, DataOP, DataT1
# import warnings
# from .DataDictXXX import DataDictFilenameInfo, DataDictLaserInfo, DataDictPathOpticsInfo
# from .Dict26 import Dict26
#
#
# class DataMultiXXX:
#
#     def __init__(self, filename_list, folder_name):
#         self.filename_list = filename_list
#         if not self.filename_list:
#             raise RuntimeError('Filename list is empty')
#         self.size = len(self.filename_list)
#         self.folder_name = folder_name
#         self.data_object_list = self.get_data_object_list()
#
#         self.multi_file_info = DataDictFilenameInfo()
#         self.fai_head_keys_dict = Dict26()
#         self.get_fai_head_keys_dict()
#         self.multi_measurement_variable = Dict26(spacer=' ')
#         self.get_multi_file_info()
#
#     def get_data_object_list(self):
#         warnings.warn('Define your own get_data_list() function')
#         return []
#
#     def get_multi_file_info(self):
#
#         self.initialize_multi_file_info()
#
#         for i in range(self.size):  # for object in object list
#             data_object = self.data_object_list[i]
#             for key in data_object.file_info:  # iterate through object keys
#                 if key in self.fai_head_keys_dict:  # if this key is one of the headkeys of fai
#                     for sub_key in data_object.file_info[key]:  # iterate through the sub_keys
#                         self.multi_file_info[key][sub_key][i] = data_object.file_info[key][sub_key]
#                 else:
#                     self.multi_file_info[key][i] = data_object.file_info[key]
#
#         # # compress identical information to 1 value instead of a list
#         for key in self.multi_file_info:
#             if key in self.fai_head_keys_dict:
#                 for sub_key in self.multi_file_info[key]:
#                     value_list = self.multi_file_info[key][sub_key]
#                     if all(value == value_list[0] for value in value_list):
#                         self.multi_file_info[key][sub_key] = value_list[0]
#                     else:
#                         self.multi_measurement_variable[key + ': ' + sub_key] = value_list
#             else:
#                 value_list = self.multi_file_info[key]
#                 if all(value == value_list[0] for value in value_list):
#                     self.multi_file_info[key] = value_list[0]
#                 else:
#                     self.multi_measurement_variable[key] = value_list
#
#     def initialize_multi_file_info(self):
#
#         # Initialize multi_file_info values to none lists instead of single none
#         # and take care of additional information sub dicts
#         for key in self.multi_file_info:
#             if key in self.fai_head_keys_dict:  # if this key is one of the fai head keys
#                 self.multi_file_info[key] = self.fai_head_keys_dict[key]
#                 for sub_key in self.multi_file_info[key]:
#                     self.multi_file_info[key][sub_key] = [None]*self.size
#             else:
#                 self.multi_file_info[key] = [None]*self.size
#
#     def get_fai_head_keys_dict(self):
#         # get which dictionary keys are sub_dictionaries
#         lsr_info = DataDictLaserInfo('Laser')
#         exc_info = DataDictPathOpticsInfo('Excitation Path Optics')
#         col_info = DataDictPathOpticsInfo('Collection Path Optics')
#         enc_info = DataDictPathOpticsInfo('Excitation and Collection Path Optics')
#
#         file_additional_info_list = [lsr_info, exc_info, col_info, enc_info]
#
#         # returning head_key dict for all fai
#         self.fai_head_keys_dict = {fai.head_key: fai for fai in file_additional_info_list}
#
#
# class DataMultiSIF(DataMultiXXX):
#
#     def __init__(self, file_name_list, second_order=False, wavelength_offset=0, background_per_cycle=300,
#                  folder_name='.', from_video=True):
#         self.second_order = second_order
#         self.wavelength_offset = wavelength_offset
#         self.background_per_cycle = background_per_cycle
#         self.from_video = from_video
#         super().__init__(file_name_list, folder_name)
#
#     def get_data_object_list(self):
#         data_object_list = []
#         for file_name in self.filename_list:
#             data_object_list.append(DataSIF(file_name=file_name,
#                                             second_order=self.second_order,
#                                             wavelength_offset=self.wavelength_offset,
#                                             background_per_cycle=self.background_per_cycle,
#                                             folder_name=self.folder_name,
#                                             from_video=self.from_video))
#
#         return data_object_list
#
#
# class DataMultiOP(DataMultiXXX):
#
#     def __init__(self, file_name_list, folder_name='.'):
#
#         super().__init__(file_name_list, folder_name)
#
#     def get_data_object_list(self):
#         data_object_list = []
#         for file_name in self.filename_list:
#             data_object_list.append(DataOP(file_name=file_name, folder_name=self.folder_name))
#
#         return data_object_list
#
#
# class DataMultiT1(DataMultiXXX):
#
#     def __init__(self, file_name_list, folder_name='.'):
#
#         super().__init__(file_name_list, folder_name)
#
#     def get_data_object_list(self):
#         data_object_list = []
#         for file_name in self.filename_list:
#             data_object_list.append(DataT1(file_name=file_name, folder_name=self.folder_name))
#
#         return data_object_list
