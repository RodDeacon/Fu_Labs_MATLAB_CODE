# 2021-04-08
# This code was made for use in the Fu lab
# by Vasilis Niaouris

from dataclasses import dataclass
from pandas import DataFrame

@dataclass
class qdlf:
    data: DataFrame
    parameters: dataclass



