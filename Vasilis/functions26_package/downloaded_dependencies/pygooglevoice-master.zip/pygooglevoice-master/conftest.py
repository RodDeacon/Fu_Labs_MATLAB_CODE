collect_ignore = [
    # ignore these tests because they require input
    'googlevoice/tests.py',

    # ignore this test because it requires BeautifulSoup
    'examples/parse_sms.py',
]
